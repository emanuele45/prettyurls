<?php
//	Version: 0.9; PrettyUrls

require_once(dirname(__FILE__) . '/PrettyUrls.english.php');

//	Admin chrome
$txt['pretty_chrome_title'] = 'Administration de Pretty URLs';
$txt['pretty_chrome_menu_settings'] = 'Param&egrave;tres';
$txt['pretty_chrome_menu_maintenance'] = 'Maintenance';

//	Settings page
$txt['pretty_chrome_caption_settings'] = 'Titre des param&egrave;tres';
$txt['pretty_chrome_page_title_settings'] = 'Param&egrave;tres de Pretty URLs';
$txt['pretty_core_settings'] = 'Param&egrave;tres principaux';
$txt['pretty_enable'] = 'Autoriser la r&eacute;&eacute;criture des URLs';
$txt['pretty_filters'] = 'Filtres de r&eacute;&eacute;criture des URLs';
$txt['pretty_save'] = 'Sauvegarder les changements';

?>
